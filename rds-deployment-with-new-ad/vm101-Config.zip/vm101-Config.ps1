Configuration xRDSHMaster {
    param (
        [parameter(Mandatory)]
        [string]$domainName,

        [parameter(Mandatory)]
        [PSCredential]$domainCreds,

        [int]$retryCount=20,

        [int]$retryIntervalSec = 30
    )

    ## Import all the neccesary modules, you can get these modules on GitHub
    Import-DscResource -ModuleName xActiveDirectory, xNetworking, xStorage, xPendingReboot
    ## Import the domain credentials into the $domainCreds
    $domainCreds = New-Object System.Management.Automation.PSCredential ("$domainName\$($adminCreds.UserName)", $adminCreds.Password)

    Node localhost {
        
        LocalConfigurationManager {
            RebootNodeIfNeeded = $true
        }

        WindowsFeature DNS {
            Name = "DNS"
            Ensure = "Present"
        }

        WindowsFeature DNSTools {
            Name = "RSAT-DNS-Server"
            Ensure = "Present"
            DependsOn = "[WindowsFeature]DNS"
        }

        xDNSServerAddress DNSServerAddress {
            Address = "127.0.0.1"
            InterfaceAlias = $InterfaceAlias
            AddressFamily = "IPv4"
            DependsOn = "[WindowsFeature]DNS"
        }

        xWaitForDisk Disk2 {
            DiskId = 2
            RetryIntervalSec = $retryIntervalSec
            RetryCount = $retryCount
        }

        xDisk AddDisk2 {
            DiskId =  = 2
            DriveLetter = "N"
            DependsOn = "[xWaitForDisk]Disk2"
        }

        WindowsFeature ADDSInstall {
            Name = "AD-Domain-Services"
            Ensure = "Present"
            DependsOn = "[WindowsFeature]DNS"
        }
    }
}

Configuration xSessionHost {
    param(
        [parameter(Mandatory)]
        [string]$domainName,
        
        [parameter(Mandatory)]
        [SecureString]$domainCreds,

        [int]$retryCount = 20,
        [int]$retryIntervalSec = 30
    )
    ## Import all the neccesary modules, you can get these modules on GitHub
    Import-DscResource -ModuleName xActiveDirectory, xComputerManagement, xNetworking
    ## Import the domain credentials into the $domainCreds
    $domainCreds = New-Object System.Management.Automation.PSCredential ("$domainName\$($adminCreds.UserName)", $adminCreds.Password)

    node localhost{

        LocalConfigurationManager {
            RebootNodeIfNeeded = $true
            ConfigurationMode = "ApplyOnly"
        }

        WindowsFeature ADPowershell {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
        }   

        xWaitForADDomain DscForestWait {
            DomainName = $domainName
            DomainUserCredential = $domainCreds
            RetryIntervalSec = $retryIntervalSec
            RetryCount = $retryCount
            DependsOn = "[WindowsFeature]ADPowerShell"
        }

        xComputer DomainJoin {
            Name = $env:COMPUTERNAME
            DomainName = $domainName
            Credential = $domainCreds
            DependsOn = "[xWaitForADDomain]DscForestWait"
        }

        xFirewall FirewallRuleForGWRDSH {
            Direction = "Inbound"
            Name = "Firewall-GW-RDSH-TCP-In"
            Description = "Inbound rule for CB to allow TCP traffic for configuring GW and RDSH machines during deployment."
            Group = "Connection Broker"
            Enabled = "True"
            Action = "Allow"
            Protocol = "TCP"
            LocalPort = "5985"
            Ensure = "Present"
        }

        WindowsFeature RDS-RD-Server {
            Name = "RDS-RD-Server"
            Ensure = "Present"
        }
    }
}
