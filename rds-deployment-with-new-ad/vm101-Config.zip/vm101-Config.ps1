Configuration xRDSHMaster {
    param (
        [Parameter(Mandatory)]
        [String] $domainName,

        [Parameter(Mandatory)]
        [PSCredential]$adminCreds,

        [Int]$retryCount=30,
        [Int]$retryIntervalSec=60,

        [String]$externalFqdn,
        
        [Int]$numberOfRdshInstances,
        [String]$sessionHostNamingPrefix = "AZW2K16RDSH",

        [String]$collectionName,

        [String]$collectionDescription
    )

    Import-DscResource -ModuleName PSDesiredStateConfiguration -ModuleVersion 1.1
    ## Import all the neccesary modules, you can get these modules on GitHub
    Import-DscResource -ModuleName xActiveDirectory, xNetworking, xStorage, xPendingReboot, xRemoteDesktopSessionHost
    ## Import the domain credentials into the $domainCreds
    $domainCreds = New-Object System.Management.Automation.PSCredential ("$domainName\$($adminCreds.UserName)", $adminCreds.Password)    

    $Interface = Get-NetAdapter | Where-Object Name -like "Ethernet*" | Select-Object -First 1
    $InterfaceAlias = $($Interface.Name)

    $localHost = [System.Net.DNS]::GetHostByName((hostname)).hostName

    if ($sessionHostNamingPrefix)
    { 
        $sessionHosts = @( 0..($numberOfRdshInstances-1) | % { "$sessionHostNamingPrefix$_.$domainname"} )
    }
    else
    {
        $sessionHosts = @( $localhost )
    }

    if (-not $collectionName)         { $collectionName = "Desktop Collection" }
    if (-not $collectionDescription)  { $collectionDescription = "A sample RD Session collection up in cloud." }

        
    Node localhost {
        
        LocalConfigurationManager {
            RebootNodeIfNeeded = $true
            ConfigurationMode = "ApplyOnly"
        }

        WindowsFeature DNS {
            Name = "DNS"
            Ensure = "Present"
        }

        WindowsFeature DNSTools {
            Name = "RSAT-DNS-Server"
            Ensure = "Present"
            DependsOn = "[WindowsFeature]DNS"
        }

        xDNSServerAddress DNSServerAddress {
            Address = "127.0.0.1","8.8.8.8"
            InterfaceAlias = $InterfaceAlias
            AddressFamily = "IPv4"
            DependsOn = "[WindowsFeature]DNS"
        }

        xWaitForDisk Disk2 {
            DiskId = 2
            RetryIntervalSec = $retryIntervalSec
            RetryCount = $retryCount
        }

        xDisk NVolume {
            DiskId = 2
            DriveLetter = "N"
            FSFormat = "NTFS"
            FSLabel = "Active Directory Data"
            DependsOn = "[xWaitForDisk]Disk2"
        }

        WindowsFeature ADDSInstall {
            Name = "AD-Domain-Services"
            Ensure = "Present"
            DependsOn = "[WindowsFeature]DNS"
        }

        WindowsFeature ADDSTools {
            Name = "RSAT-ADDS"
            Ensure = "Present"
            IncludeAllSubFeature = $True
        }

        xADDomain FirstADS {
            DomainName = $domainName
            DomainAdministratorCredential = $domainCreds
            SafemodeAdministratorPassword = $domainCreds
            DatabasePath = "N:\NTDS"
            LogPath = "N:\NTDS"
            SysvolPath = "N:\SYSVOL"
            DependsOn = "[WindowsFeature]ADDSInstall"
        }

        WindowsFeature RDS-Gateway {
            Name = "RDS-Gateway"
            Ensure = "Present"
            DependsOn = "[xADDomain]FirstADS"
        }

        WindowsFeature RDS-Web-Access {
            Name = "RDS-Web-Access"
            Ensure = "Present"
            DependsOn = "[WindowsFeature]RDS-Gateway"
        }

        WindowsFeature RSAT-RDS-Tools {
            Name = "RSAT-RDS-Tools"
            Ensure = "Present"
            IncludeAllSubFeature = $True
        }

        WindowsFeature RDS-Licensing {
            Name = "RDS-Licensing"
            Ensure = "Present"
        }

        xRDSessionDeployment Deployment {
            ConnectionBroker = "AZW2K16DOM01.rdshOnAzure.local"
            WebAccessServer = "AZW2K16DOM01.rdshOnAzure.local"
            SessionHosts = $sessionHosts

            PsDscRunAsCredential = $domainCreds
        }

        xRDServer AddLicenseServer {
            Role = "RDS-Licensing"
            Server = "AZW2K16DOM01.rdshOnAzure.local"
            DependsOn = "[xRDSessionDeployment]Deployment"

            PsDscRunAsCredential = $domainCreds
        }

        xRDLicenseConfiguration LicenseConfiguration {
            ConnectionBroker = "AZW2K16DOM01.rdshOnAzure.local"
            LicenseServers = "AZW2K16DOM01.rdshOnAzure.local"
            LicenseMode = "PerUser"

            DependsOn = "[xRDServer]AddLicenseServer"

            PsDscRunAsCredential = $domainCreds
        }

        xRDServer AddGatewayServer {
            Role = "RDS-Gatway"
            Server = "AZW2K16DOM01.rdshOnAzure.local"
            GatewayExternalFQDN = $externalFQDN

            DependsOn = "[xRDLicenseConfiguration]LicenseConfiguration"

            PsDscRunAsCredential = $domainCreds
        }
<#
        xRDGatewayConfiguration GatewayConfiguration {
            ConnectionBroker = "AZW2K16DOM01.rdshOnAzure.local"
            GatewayServer = "AZW2K16DOM01.rdshOnAzure.local"
            ExternalFQDN = $externalFQDN
            GatewayMode = "Custom"
            LogonMethod = "Password"
            UseCachedCredentials = $True
            BypassLocal = $False

            DependsOn = "[xRDServer]AddGatewayServer"

            PsDscRunAsCredential = $domainCreds
        }

        xRDSessionCollection Collection {
            ConnectionBroker = "AZW2K16DOM01.rdshOnAzure.local"
            CollectionName = $CollectionName
            CollectionDescription = $collectionDescription
            SessionHosts = $sessionHosts 
            
            DependsOn = "[xRDGatewayConfiguration]GatewayConfiguration"

            PsDscRunAsCredential = $domainCreds
        }
#>
    }
}

Configuration xSessionHost {
    param(
        [parameter(Mandatory)]
        [string]$domainName,

        [Parameter(Mandatory)]
        [PSCredential]$adminCreds,

        [int]$retryCount = 20,
        [int]$retryIntervalSec = 30
    )
    ## Import all the neccesary modules, you can get these modules on GitHub
    Import-DscResource -ModuleName xActiveDirectory, xComputerManagement, xNetworking
    ##$securePassword = ConvertTo-SerucreString -AsPlainText $adminPassword -Force;
    ##$domainCreds = New-Object System.Management.Automation.PSCredential($adminUsername, $securePassword);

    ## Import the domain credentials into the $domainCreds
    $domainCreds = New-Object System.Management.Automation.PSCredential ("$domainName\$($adminCreds.UserName)", $adminCreds.Password)
    
    node localhost{

        LocalConfigurationManager {
            RebootNodeIfNeeded = $true
            ConfigurationMode = "ApplyOnly"
        }

        WindowsFeature ADPowershell {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
        }   

        xWaitForADDomain DscForestWait {
            DomainName = $domainName
            DomainUserCredential = $domainCreds
            RetryIntervalSec = $retryIntervalSec
            RetryCount = $retryCount
            DependsOn = "[WindowsFeature]ADPowerShell"
        }

        xComputer DomainJoin {
            Name = $env:COMPUTERNAME
            DomainName = $domainName
            Credential = $domainCreds
            DependsOn = "[xWaitForADDomain]DscForestWait"
        }

        xFirewall FirewallRuleForGWRDSH {
            Direction = "Inbound"
            Name = "Firewall-GW-RDSH-TCP-In"
            Description = "Inbound rule for CB to allow TCP traffic for configuring GW and RDSH machines during deployment."
            Group = "Connection Broker"
            Enabled = "True"
            Action = "Allow"
            Protocol = "TCP"
            LocalPort = "5985"
            Ensure = "Present"
        }

        WindowsFeature RDS-RD-Server {
            Name = "RDS-RD-Server"
            Ensure = "Present"
        }
    }
}
