Configuration xConfig {
    param (
        [Parameter(Mandatory)]
        [String] $domainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$adminCreds,

        [Int]$retryCount = 30,
        [Int]$retryIntervalSec = 60,

        [Parameter(Mandatory)]
        [String]$ConnectionBroker,
        
        [Parameter(Mandatory)]
        [String]$WebAccessServer,

        [String]$externalFqdn,
        
        [Int]$numberOfRdshInstances,
        [String]$sessionHostNamingPrefix,

        [String]$collectionName,

        [String]$collectionDescription
    )

    $localHost = [System.Net.DNS]::GetHostByName((hostname)).hostName
    
    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Import-DscResource -ModuleName xActiveDirectory, xNetworking, xStorage, xPendingReboot, xRemoteDesktopSessionHost, xComputerManagement
    #$username = $adminCreds.UserName -split '\\' | select -last 1
    $domainCreds = New-Object System.Management.Automation.PSCredential("${domainName}\$($adminCreds.UserName)", $adminCreds.Password) 

    $Interface = Get-NetAdapter | Where-Object Name -like "Ethernet*" | Select-Object -First 1
    $InterfaceAlias = $($Interface.Name)

    if ($sessionHostNamingPrefix)
    { 
        $sessionHosts = @( 0..($numberOfRdshInstances-1) | % { "$sessionHostNamingPrefix$_.$domainname"} )
    }
    else
    {
        $sessionHosts = @( $localhost )
    }

    if (-not $collectionName)         { $collectionName = "Desktop Collection" }
    if (-not $collectionDescription)  { $collectionDescription = "A sample RD Session collection up in cloud." }
        
@{
    AllNodes = @(
            @{
                NodeName= $ConnectionBroker
                PSDscAllowPlainTextPassword=$true
                PSDscAllowDomainUser = $true
            }
            @{
                NodeName= $WebAccessServer
                PSDscAllowPlainTextPassword=$true
                PSDscAllowDomainUser = $true
            }
        )
    }

    Node $ConnectionBroker {
        
        LocalConfigurationManager {
            RebootNodeIfNeeded = $true
            ConfigurationMode = "ApplyOnly"
            ActionAfterReboot = 'ContinueConfiguration'
        }

        WindowsFeature DNS {
            Name = "DNS"
            Ensure = "Present"
        }

        WindowsFeature DNSTools {
            Name = "RSAT-DNS-Server"
            Ensure = "Present"
            DependsOn = "[WindowsFeature]DNS"
        }

        xDNSServerAddress DNSServerAddress {
            Address = "127.0.0.1","8.8.8.8"
            InterfaceAlias = $InterfaceAlias
            AddressFamily = "IPv4"
            DependsOn = "[WindowsFeature]DNS"
        }

        xWaitForDisk Disk2 {
            DiskId = 2
            RetryIntervalSec = $retryIntervalSec
            RetryCount = $retryCount
        }

        xDisk NVolume {
            DiskId = 2
            DriveLetter = "N"
            FSFormat = "NTFS"
            FSLabel = "Active Directory Data"
            DependsOn = "[xWaitForDisk]Disk2"
        }

        WindowsFeature ADDSInstall {
            Name = "AD-Domain-Services"
            Ensure = "Present"
            DependsOn = "[WindowsFeature]DNS"
        }

        WindowsFeature ADDSTools {
            Name = "RSAT-ADDS"
            Ensure = "Present"
            IncludeAllSubFeature = $True
        }

        xADDomain FirstADS {
            DomainName = $domainName
            DomainAdministratorCredential = $domainCreds
            SafemodeAdministratorPassword = $domainCreds
            DatabasePath = "N:\NTDS"
            LogPath = "N:\NTDS"
            SysvolPath = "N:\SYSVOL"
            DependsOn = "[WindowsFeature]ADDSInstall"
        }
    }

    Node $WebAccessServer {
        
        LocalConfigurationManager {
            RebootNodeIfNeeded = $true
            ConfigurationMode = "ApplyOnly"
        }

        WindowsFeature ADPowershell {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
        }   

        xWaitForADDomain DscForestWait {
            DomainName = $domainName
            DomainUserCredential = $domainCreds
            RetryIntervalSec = $retryIntervalSec
            RetryCount = $retryCount
            DependsOn = "[WindowsFeature]ADPowerShell"
        }

        xComputer DomainJoin {
            Name = $env:COMPUTERNAME
            DomainName = $domainName
            Credential = $domainCreds
            DependsOn = "[xWaitForADDomain]DscForestWait"
        }

        xFirewall FirewallRuleForGWRDSH {
            Direction = "Inbound"
            Name = "Firewall-GW-RDSH-TCP-In"
            Description = "Inbound rule for CB to allow TCP traffic for configuring GW and RDSH machines during deployment."
            Group = "Connection Broker"
            Enabled = "True"
            Action = "Allow"
            Protocol = "TCP"
            LocalPort = "5985"
            Ensure = "Present"
        }

        WindowsFeature RDS-Gateway {
            Ensure = "Present"
            Name = "RDS-Gateway"
        }

        WindowsFeature RDS-Web-Access {
            Ensure = "Present"
            Name = "RDS-Web-Access"
        }

    }
    Node $ConnectionBroker {
        
        LocalConfigurationManager {
            RebootNodeIfNeeded = $true
            ConfigurationMode = "ApplyOnly"
        }

        WindowsFeature RSAT-RDS-Tools {
            DependsOn = "[xADDomain]FirstADS"

            Name = "RSAT-RDS-Tools"
            Ensure = "Present"
            IncludeAllSubFeature = $True
            }

        WindowsFeature RDS-Licensing {
            Name = "RDS-Licensing"
            Ensure = "Present"
            }

        xRDSessionDeployment Deployment {
            ConnectionBroker = $ConnectionBroker + "." + $DomainName
            WebAccessServer = $WebAccessServer + "." + $DomainName
            SessionHosts = $sessionHosts

            PsDscRunAsCredential = $domainCreds
            }

        xRDServer AddLicenseServer {
            Role = "RDS-Licensing"
            Server = $ConnectionBroker + "." + $DomainName
            DependsOn = "[xRDSessionDeployment]Deployment"

            PsDscRunAsCredential = $domainCreds
            }

        xRDLicenseConfiguration LicenseConfiguration {
            ConnectionBroker = $ConnectionBroker + "." + $DomainName
            LicenseServers = $ConnectionBroker + "." + $DomainName
            LicenseMode = "PerUser"

            DependsOn = "[xRDServer]AddLicenseServer"

            PsDscRunAsCredential = $domainCreds
            }

        xRDServer AddGatewayServer {
            Role = "RDS-Gateway"
            Server = $WebAccessServer + "." + $DomainName
            GatewayExternalFQDN = $WebAccessServer + "." + $DomainName

            DependsOn = "[xRDLicenseConfiguration]LicenseConfiguration"

            PsDscRunAsCredential = $domainCreds
            }

        xRDGatewayConfiguration GatewayConfiguration {
            ConnectionBroker = $ConnectionBroker + "." + $DomainName
            GatewayServer = $WebAccessServer + "." + $DomainName
            ExternalFQDN = $WebAccessServer + "." + $DomainName
            GatewayMode = "Custom"
            LogonMethod = "Password"
            UseCachedCredentials = $True
            BypassLocal = $False

            DependsOn = "[xRDServer]AddGatewayServer"

            PsDscRunAsCredential = $domainCreds
            }

        xRDSessionCollection Collection {
            ConnectionBroker = $ConnectionBroker + "." + $DomainName
            CollectionName = $CollectionName
            CollectionDescription = $collectionDescription
            SessionHosts = $sessionHosts 
            
            DependsOn = "[xRDGatewayConfiguration]GatewayConfiguration"

            PsDscRunAsCredential = $domainCreds
            }
    }
}

Configuration xSessionHost {
    param(
        [parameter(Mandatory)]
        [string]$domainName,

        [Parameter(Mandatory)]
        [PSCredential]$adminCreds,

        [int]$retryCount = 30,
        [int]$retryIntervalSec = 60
    )
    ## Import all the neccesary modules, you can get these modules on GitHub
    Import-DscResource -ModuleName xActiveDirectory, xComputerManagement, xNetworking, xPendingReboot

    ## Import the domain credentials into the $domainCreds
    $domainCreds = New-Object System.Management.Automation.PSCredential ("$domainName\$($adminCreds.UserName)", $adminCreds.Password)
    
    node localhost{

        LocalConfigurationManager {
            RebootNodeIfNeeded = $true
            ConfigurationMode = "ApplyOnly"
        }

        WindowsFeature ADPowershell {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
        }   

        xWaitForADDomain DscForestWait {
            DomainName = $domainName
            DomainUserCredential = $domainCreds
            RetryIntervalSec = $retryIntervalSec
            RetryCount = $retryCount
            DependsOn = "[WindowsFeature]ADPowerShell"
        }

        xComputer DomainJoin {
            Name = $env:COMPUTERNAME
            DomainName = $domainName
            Credential = $domainCreds
            DependsOn = "[xWaitForADDomain]DscForestWait"
        }

        xFirewall FirewallRuleForGWRDSH {
            Direction = "Inbound"
            Name = "Firewall-GW-RDSH-TCP-In"
            Description = "Inbound rule for CB to allow TCP traffic for configuring GW and RDSH machines during deployment."
            Group = "Connection Broker"
            Enabled = "True"
            Action = "Allow"
            Protocol = "TCP"
            LocalPort = "5985"
            Ensure = "Present"
        }

        WindowsFeature RDS-RD-Server {
            Name = "RDS-RD-Server"
            Ensure = "Present"
        }
    }
}